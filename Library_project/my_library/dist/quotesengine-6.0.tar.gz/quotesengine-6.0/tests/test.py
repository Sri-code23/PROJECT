import QuotesEngine.simple as s
import QuotesEngine.quotes as q

  
obj1=s.Motivate.username("ravi")


obj2=q.Motivater.username("babauu")
obj2.motivate()