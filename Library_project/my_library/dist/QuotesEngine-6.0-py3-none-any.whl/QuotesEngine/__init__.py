from .quotes import Motivater
from .simple import Motivate



